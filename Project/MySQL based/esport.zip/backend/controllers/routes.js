const mysql=require('mysql');

const conn=mysql.createConnection({
    user:"root",
    password:"",
    database:"esport_db"

});

const eventList=(req,res)=>{
    conn.query(`SELECT * 
        FROM events`
    ,(err,rows)=>{
        if(err){
            res.status(400).json(err);
        } else {
            res.status(200).json(rows);
        }
    });
}

const playersList=(req,res)=>{
    conn.query(`SELECT id,
        inviteable,
        full_name,
        usr_name,
        usna_last_mod_date,
        usna_mod_num_remain,
        date_of_birth,
        school,
        clss,
        email_address,
        email_last_mod_date,
        phone_num,
        om_identifier,
        'status',
        discord_name
        FROM players`
    ,(err,rows)=>{
        if(err){
            res.status(400).json(err);
        } else {
            res.status(200).json(rows);
        }
    });
}

const tournamentList=(req,res)=>{
    conn.query(`SELECT id, 
        name, 
        num_participant, 
        team_num, 
        start_date, 
        end_date, 
        game_mode, 
        max_participant, 
        apn_start, 
        apn_end, 
        details 
        FROM tournaments`
    ,(err,rows)=>{
        if(err){
            res.status(400).json(err);
        } else {
            res.status(200).json(rows);
        }
    });
}




