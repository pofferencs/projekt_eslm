const mysql=require('mysql');

const conn=mysql.createConnection({
    user:"root",
    password:"",
    database:"esport_db"

});

const tournamentList=(req,res)=>{
    conn.query(`SELECT id, 
        name, 
        num_participant, 
        team_num, 
        start_date, 
        end_date, 
        game_mode, 
        max_participant, 
        apn_start, 
        apn_end, 
        details 
        FROM tournaments`
    ,(err,rows)=>{
        if(err){
            res.status(400).json(err);
        } else {
            res.status(200).json(rows);
        }
    });
}

module.exports={
    tournamentList
}