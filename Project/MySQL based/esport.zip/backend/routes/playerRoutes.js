const express=require('express');
const router=express.Router();
const {playersList} = require('../controllers/playerController');

router.get('/jatekosok',playersList);

module.exports=router;