const express=require('express');
const router=express.Router();
const {tournamentList} = require('../controllers/tournamentController');

router.get('/versenyek',tournamentList);

module.exports=router;