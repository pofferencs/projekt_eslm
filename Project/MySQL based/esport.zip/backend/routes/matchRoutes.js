const express=require('express');
const router=express.Router();
const {matchList} = require('../controllers/matchController');

router.get('/meccsek',matchList);

module.exports=router;