import { useState, useEffect } from "react";
import { useNavigate } from 'react-router-dom';


function Main() {
  
    


  return (
    <>
      <div>
        <h1 className="text-center mt-5 font-bold">Lorem ipsum dolor sit amet.</h1>
      </div>
        
    </>
  )
}

export default Main
