import { useState, useEffect } from "react";
import { useNavigate } from 'react-router-dom';
import Players from "./Players";


function Main() {
  
    


  return (
    <>
      <div>
        <h1 className="text-center mt-5 mb-5 font-bold text-3xl">Weblap</h1>
      </div>

      
        
    </>
  )
}

export default Main
