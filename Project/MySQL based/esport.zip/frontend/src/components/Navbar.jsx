import { useState, useEffect } from "react";
import { useNavigate } from 'react-router-dom';
import { Link } from "react-router-dom";


function Navbar() {
  
    


  return (
    <div className="navbar bg-base-200">
        <div className="flex-1">
            <Link className="btn btn-ghost text-xl ml-3 font-bold" to='/'>ESPORT</Link>
        </div>
        <div className="pr-5">
            <div className="dropdown dropdown-bottom dropdown-end">
                <div tabIndex={0} role="button" className="btn bg-base-200 m-1 text-black">Adatok</div>
                    <ul tabIndex={0} className="dropdown-content menu bg-base-100 rounded-box z-[1] w-52 p-2 shadow">
                            <li><Link to='/jatekosok'>Játékosok</Link></li>
                            <li><Link target="_blank" to={`${import.meta.env.VITE_BASE_URL}/esemenyek`}>Események</Link></li>
                            <li><Link target="_blank" to={`${import.meta.env.VITE_BASE_URL}/versenyek`}>Versenyek</Link></li>
                            <li><Link target="_blank" to={`${import.meta.env.VITE_BASE_URL}/meccsek`}>Meccsek</Link></li>
                    </ul>
            </div>
            
            <div className="dropdown dropdown-bottom dropdown-end">
                <div tabIndex={0} role="button" className="btn bg-base-200 m-1 text-black">Listák</div>
                    <ul tabIndex={0} className="dropdown-content menu bg-base-100 rounded-box z-[1] w-52 p-2 shadow">
                            <li><Link target="_blank" to={`${import.meta.env.VITE_BASE_URL}/jatekosok`}>Játékosok</Link></li>
                            <li><Link target="_blank" to={`${import.meta.env.VITE_BASE_URL}/esemenyek`}>Események</Link></li>
                            <li><Link target="_blank" to={`${import.meta.env.VITE_BASE_URL}/versenyek`}>Versenyek</Link></li>
                            <li><Link target="_blank" to={`${import.meta.env.VITE_BASE_URL}/meccsek`}>Meccsek</Link></li>
                    </ul>
            </div>

        </div>
    </div>
  )
}

export default Navbar









