import { useState, useEffect, useContext } from "react";
import { useNavigate } from 'react-router-dom';
import EsportContext from "../context/EsportContext";
import Player from "./Player";


function Players() {
  
    const {players} = useContext(EsportContext)
    


  return (
    <>
        <div className="grid xl:grid-cols-3 lg:grid-cols-2 md:grid-cols-1 sm:grid-cols-1 justify-items-center">
            {
                players.map((player,i)=><Player key={i} player={player}/>)
            }
        </div>


    </>
  )
}

export default Players
