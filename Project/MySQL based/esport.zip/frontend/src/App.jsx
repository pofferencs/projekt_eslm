import { useState } from 'react';
import { BrowserRouter } from 'react-router-dom';
import { Route, Routes, Navigate } from 'react-router-dom';
import reactLogo from './assets/react.svg';
import viteLogo from '/vite.svg';
import Navbar from './components/Navbar';
import Main from './components/Main';
import './App.css';
import { EsportProvider } from './context/EsportContext';


function App() {
  

  return (
    <>
    <BrowserRouter>
    <EsportProvider>
      <Navbar/>
      <Routes>
        <Route path='/' element={<Main />} />
        <Route path='*' element={<Navigate to='/'/>} />
      </Routes>
      </EsportProvider>
      </BrowserRouter>
    </>
  )
}

export default App
