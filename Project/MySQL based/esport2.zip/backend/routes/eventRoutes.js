const express=require('express');
const router=express.Router();
const {eventList} = require('../controllers/eventController');

router.get('/esemenyek',eventList);

module.exports=router;