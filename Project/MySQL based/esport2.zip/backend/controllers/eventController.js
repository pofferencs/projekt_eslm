const mysql=require('mysql');

const conn=mysql.createConnection({
    user:"root",
    password:"",
    database:"esport_db"

});

const eventList=(req,res)=>{
    conn.query(`SELECT * 
        FROM events`
    ,(err,rows)=>{
        if(err){
            res.status(400).json(err);
        } else {
            res.status(200).json(rows);
        }
    });
}

module.exports={
    eventList
}