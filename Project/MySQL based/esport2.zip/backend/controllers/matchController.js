const mysql=require('mysql');

const conn=mysql.createConnection({
    user:"root",
    password:"",
    database:"esport_db"

});

const matchList=(req,res)=>{
    conn.query(`SELECT m.id, 
        m.status, 
        m.place, 
        m.dte, 
        m.details, 
        m.winner, 
        m.rslt, 
        m.tem1_id, 
        m.tem2_id 
        FROM matches m;`
    ,(err,rows)=>{
        if(err){
            res.status(400).json(err);
        } else {
            res.status(200).json(rows);
        }
    });
}

module.exports={
    matchList
}