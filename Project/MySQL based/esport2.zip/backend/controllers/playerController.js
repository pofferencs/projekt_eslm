const mysql=require('mysql');

const conn=mysql.createConnection({
    user:"root",
    password:"",
    database:"esport_db"

});

const playersList=(req,res)=>{
    conn.query(`SELECT id,
        inviteable,
        full_name,
        usr_name,
        usna_last_mod_date,
        usna_mod_num_remain,
        date_of_birth,
        school,
        clss,
        email_address,
        email_last_mod_date,
        phone_num,
        om_identifier,
        status,
        discord_name
        FROM players`
    ,(err,rows)=>{
        if(err){
            res.status(400).json(err);
        } else {
            res.status(200).json(rows);
        }
    });
}

module.exports={
    playersList
}