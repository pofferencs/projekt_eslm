import { useState,useEffect,createContext } from "react";
import { useNavigate } from "react-router-dom";

const EsportContext=createContext();

export const EsportProvider=({children})=>{
    const [players,setPlayers]=useState([]);
    const [events,setEvents]=useState([]);
    const [tournaments,setTournament]=useState([]);
    const [matches,setMatches]=useState([]);
    const [refresh,setRefresh]=useState(false);

    useEffect(()=>{
        fetch(`${import.meta.env.VITE_BASE_URL}/jatekosok`)
        .then(res=>res.json())
        .then(adat=>setPlayers(adat))
        .catch(err=>console.log(err));

    },[refresh]);

    useEffect(()=>{
        fetch(`${import.meta.env.VITE_BASE_URL}/esemenyek`)
        .then(res=>res.json())
        .then(adat=>setEvents(adat))
        .catch(err=>console.log(err));

    },[refresh]);

    useEffect(()=>{
        fetch(`${import.meta.env.VITE_BASE_URL}/versenyek`)
        .then(res=>res.json())
        .then(adat=>setTournament(adat))
        .catch(err=>console.log(err));

    },[refresh]);

    useEffect(()=>{
        fetch(`${import.meta.env.VITE_BASE_URL}/meccsek`)
        .then(res=>res.json())
        .then(adat=>setMatches(adat))
        .catch(err=>console.log(err));

    },[refresh]);

    const update=()=>{
        setRefresh(prev=>!prev);
    }

    const backendMuvelet=async (adat,method,url)=>{
        const response=await fetch(url,{
            method:method,
            headers:{'Content-type':'application/json'},
            body:JSON.stringify(adat)
        })
        const valasz=await response.text();
        update();
        alert(valasz);
    }

    return <EsportContext.Provider value={{
        players,
        events,
        tournaments,
        matches,
        backendMuvelet

    }}>{children}</EsportContext.Provider>

}

export default EsportContext;