import { useState } from 'react';
import { BrowserRouter } from 'react-router-dom';
import { Route, Routes, Navigate } from 'react-router-dom';
import reactLogo from './assets/react.svg';
import viteLogo from '/vite.svg';
import Navbar from './components/Navbar';
import Main from './components/Main';
import './App.css';
import { EsportProvider } from './context/EsportContext';
import Players from './components/Players';
import Footer from './components/Footer';


function App() {
  

  return (
    <>
    <BrowserRouter>
    <EsportProvider>
      <Navbar/>
      <div className="bg-cover" style={{backgroundColor:"#000000"}}>
      <Routes>
        <Route path='/' element={<Main />} />
        <Route path='/jatekosok' element={<Players />}/>
        <Route path='/esemenyek' />
        <Route path='/versenyek' />
        <Route path='*' element={<Navigate to='/'/>} />
        
      </Routes>
      </div>
      <Footer/>
      </EsportProvider>
      </BrowserRouter>
    </>
  )
}

export default App
