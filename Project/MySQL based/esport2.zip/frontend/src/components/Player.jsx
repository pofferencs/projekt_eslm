import { useState, useEffect } from "react";
import { useNavigate } from 'react-router-dom';
import moment from 'moment';


function Player({player}) {
  
  return (
    <div className="card bg-primary text-white w-96 shadow-xl m-5">
        <div className="card-body">
            <h2 className="card-title m-auto mb-2">{`${player.usr_name} (${player.id} - ${player.status})`}</h2>
            <p><span className="font-bold">Teljes név:</span> {player.full_name}</p>
            <p><span className="font-bold">Születési év:</span> {moment(`${player.date_of_birth}`).format('YYYY. MM. DD.')}</p>
            <p><span className="font-bold">E-mail cím:</span> {player.email_address}</p>
            <p><span className="font-bold">Telefonszám:</span> {player.phone_num}</p>
            <p><span className="font-bold">OM-azonosító:</span> {player.om_identifier}</p>
            <p><span className="font-bold">Iskola:</span> {player.school}</p>
            <p><span className="font-bold">Osztály:</span> {player.clss}</p>
        </div>
    </div>
  )
}

export default Player